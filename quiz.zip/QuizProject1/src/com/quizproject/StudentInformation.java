package com.quizproject;

// 2nd class
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class StudentInformation extends NewQuiz {
	public void getStudentInformation() {
		String remark = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your first name : ");
		String fname = sc.next();
		sc.nextLine();
		System.out.println("Enter your last name : ");
		String lname = sc.next();
		System.out.println("<<  Quiz  Started  >>");
		try {
			getquiz();
		} catch (Exception e) {
			e.printStackTrace();
		}

		updateUserInput(fname, lname, count, remark);

	}

	public void updateUserInput(String fname, String lname, int count, String remark) {
		Connection con1 = null;
		PreparedStatement ps1 = null;
		try {
			GetConnection con = new GetConnection();
			con1 = con.getConnectionDetails();
			ps1 = con1.prepareStatement("insert into studentinfo(fname,lname,remark,score)values(?,?,?,?);");
			ps1.setString(1, fname);
			ps1.setString(2, lname);
			ps1.setString(3, remark);
			ps1.setInt(4, count);
			ps1.executeUpdate();
			System.out.println("Record is inserted in database.");
			con1.close();
			ps1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println(fname + " your score is : " + count + " out of 10 .");
		if (count <= 10 && count > 8) {
			remark = "Class A";
		} else if (count <= 8 && count >= 6) {
			remark = "Class B";
		} else if (count == 5) {
			remark = "Class C";
		} else if (count < 5) {
			remark = "You are Fail";
		}
	}

}
//jump to AllStudentResult class