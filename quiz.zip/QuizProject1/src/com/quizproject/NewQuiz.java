package com.quizproject;

// 1st class 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class NewQuiz  {

	public int count;
	public  void getquiz()
	{
		NewQuiz newQuiz=new NewQuiz();
		Scanner sc=new Scanner(System.in);
		
		Map<Integer, String> map=new LinkedHashMap<Integer, String>();
		Connection connection=null;
		PreparedStatement ps=null;
		
		try{
			GetConnection con=new GetConnection();
			connection=con.getConnectionDetails();
		
		for(int i=1;i<=10;i++)
		{
			ps=connection.prepareStatement("select qid,question,option1,option2,option3 ,option4,correct_ans,aid from quiz where qid="+i);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				map.put(0, rs.getString(2));
				
				map.put(1, rs.getString(3));
				map.put(2, rs.getString(4));
				map.put(3, rs.getString(5));
				map.put(4, rs.getString(6));
				Set<Integer> s=map.keySet();
				for(Integer j:s)
				{
					System.out.println(j+" : "+map.get(j));
				}
				System.out.println("Choose correct option");
				int a=sc.nextInt();
				if(a==rs.getInt(8))
				{
					System.out.println("Right Answer : "+rs.getString(7));
					newQuiz.count++;
				}else
				{
					System.out.println("Wrong Answer");
				}
			     this.count=newQuiz.count;
				System.out.println();
			}
		}
		ps.close();
		
		connection.close();
		
		
 
		
		
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
// jump to studentinformation class