package com.quizproject;
// 5th class
public class MainMethod {
	public static void main(String[] args) {

		System.out.println("ONLINE QUIZ COMPETITION 2023\nOrganized By- Group K Team ");

		StudentInformation student = new StudentInformation();
		student.getStudentInformation();
		
		
		NewQuiz q = new NewQuiz();
		q.getquiz();
		
		student.updateUserInput(null, null, 0, null);
		
	}
}